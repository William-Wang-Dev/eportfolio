import pytest
from tower_of_hanoi import Stack, recursive_move, main


# Stack Tests

def test_stack_push():
    stack = Stack("Test Stack")
    assert stack.push(5) is True
    assert stack.push(3) is True
    assert stack.push(6) is False  # Pushing a larger value should fail
    assert len(stack) == 2


def test_stack_pop():
    stack = Stack("Test Stack")
    stack.push(5)
    stack.push(3)
    assert stack.pop() == 3
    assert stack.pop() == 5
    assert stack.pop() is None  # Popping from an empty stack should return None


# Recursive Move Test

def test_recursive_move():
    stack_a = Stack("SA")
    stack_b = Stack("SB")
    stack_c = Stack("SC")

    def print_stack():
        nonlocal stack_a, stack_b, stack_c
        # Mocking print function for testing
        return f"{stack_a}\n{stack_b}\n{stack_c}\n------------------------"

    stack_a.push(5)
    stack_a.push(4)
    stack_a.push(3)

    recursive_move(len(stack_a), stack_a, stack_c, stack_b, print_stack)

    assert str(stack_a) == "Stack SA: "
    assert str(stack_b) == "Stack SB: "
    assert str(stack_c) == "Stack SC: 5,4,3"


# Run the tests
if __name__ == "__main__":
    pytest.main()


'''
============================================================================================== test session starts ==============================================================================================
platform win32 -- Python 3.11.3, pytest-7.4.0, pluggy-1.2.0
rootdir: E:\MyPrograms\Python\recursion_demo_project
plugins: anyio-3.6.2
collected 3 items

test.py ...                                                                                                                                                                                                [100%]

=============================================================================================== 3 passed in 0.02s ===============================================================================================
