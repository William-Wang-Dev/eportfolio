"""
This module demonstrates the Tower of Hanoi problem 
by simulating the movement of disks between stacks.
"""

class Stack:
    """Class Stack simulates a tower to hold disks, 
    and larger disks cannot be placed on top of smaller disks."""

    def __init__(self, name: str):
        """Initialize a Stack object with a given name."""

        self._stack = []
        self._name = name

    def __str__(self) -> str:
        """Return a string representation of the Stack."""

        return f"Stack {self._name}: " + ",".join(map(str, self._stack))

    def __len__(self) -> int:
        """Return the number of items in the Stack."""

        return len(self._stack)

    def push(self, value) -> bool:
        """Push a value onto the top of the Stack.
        Return True if the value was successfully pushed, False otherwise.
        """

        if not self._stack or self._stack[-1] > value:
            self._stack.append(value)
            return True
        return False

    def pop(self) -> any:
        """Remove and return the top item from the Stack.
        Return None if the Stack is empty.
        """

        if self._stack:
            return self._stack.pop()
        return None


def recursive_move(num_disks, src, dest, aux, print_func):
    """Recursively move disks from the source Stack to the destination Stack.

    Parameters:
    - num_disks (int): The number of disks to move.
    - src (Stack): The source Stack.
    - dest (Stack): The destination Stack.
    - aux (Stack): The auxiliary Stack.
    - print_func (function): The function to print the state of the Stacks.
    """

    if num_disks == 0:
        return

    # If we want to move a targeted disk, we could remove non-targeted disks to aux first
    recursive_move(num_disks-1, src, aux, dest, print_func)
    # Move the targeted disk to the destination stack
    disk = src.pop()
    assert disk is not None
    result = dest.push(disk)
    assert result is True
    print_func()
    # Move the rest of the disks from the aux stack to the destination stack
    recursive_move(num_disks-1, aux, dest, src, print_func)


def main():
    """Main function to demonstrate the Tower of Hanoi problem."""

    stack_a = Stack("SA")
    stack_b = Stack("SB")
    stack_c = Stack("SC")

    def print_stack():
        """A closure function that includes all stacks and prints their info."""

        nonlocal stack_a, stack_b, stack_c
        print(f"{stack_a}")
        print(f"{stack_b}")
        print(f"{stack_c}")
        print("------------------------")

    # You can change the number of disks, this is from 5 to 1
    for disk_num in range(5, 0, -1):
        stack_a.push(disk_num)

    print("--------start--------")
    print_stack()

    # Remove all disks from SA to SC
    recursive_move(len(stack_a), stack_a, stack_c, stack_b, print_stack)

    print("--------final--------")
    print_stack()


if __name__ == "__main__":
    main()
