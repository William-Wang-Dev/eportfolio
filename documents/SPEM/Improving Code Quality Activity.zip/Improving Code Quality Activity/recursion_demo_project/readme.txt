# Tower of Hanoi

This program demonstrates the Tower of Hanoi problem by simulating the movement of disks between stacks. The Tower of Hanoi is a classic puzzle that involves three stacks and a number of disks of different sizes. The goal is to move all the disks from one stack to another, following these rules:

1. Only one disk can be moved at a time.
2. Each move consists of taking the top disk from one stack and placing it on top of another stack.
3. No disk may be placed on top of a smaller disk.

The Tower of Hanoi problem has a recursive nature, and the program uses recursion to solve it.

## Requirements

- Python 3.x

## Usage
 
1. Navigate to the project directory:
$ cd tower-of-hanoi

2. Run the program:
python recursion.py


3. Follow the instructions printed on the console to see the step-by-step movement of the disks.

## Testing

The program includes unit tests for different components. To run the tests, you can use `pytest`. Make sure you have `pytest` installed, and then run the following command in the project directory:
pytest test.py



## Contributing

Contributions are welcome! If you find any issues or have suggestions for improvements, please open an issue or submit a pull request.
